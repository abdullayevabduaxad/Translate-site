from .views import *
from django.urls import path

urlpatterns = [
    path('', index, name='index'),
    path('help/', Help, name='help'),
    path('hello/', salom2, name='hello'),
]

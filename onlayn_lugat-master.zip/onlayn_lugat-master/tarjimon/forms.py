from django import forms
from .models import Lugat


class LugatForm(forms.ModelForm):
    class Meta:
        model = Lugat
        fields = ['inglizcha', 'uzbekcha']

from django.apps import AppConfig


class TarjimonConfig(AppConfig):
    name = 'tarjimon'
